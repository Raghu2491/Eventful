package com.example.raghavendra.raghavendr_hw9;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.github.florent37.picassopalette.PicassoPalette;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Map;

import butterknife.Bind;

/**
 * Created by Raghavendra on 2/22/2016.
 */
public class Events_MyRecyclerViewAdapter extends RecyclerView.Adapter<Events_MyRecyclerViewAdapter.ViewHolder> {
    private Context mContext;
    private onCardItemClickListener cardItemClickListener;
    private List<String> mDataSet;
    int c=9;
    // @Bind(R.id.movie_item_footer) View mFooterView;

    @Override
    public int getItemViewType(int position) {

        return position;
    }
    public Events_MyRecyclerViewAdapter(Context myContext, List<String> mDataSet){
        this.mContext=myContext;
        this.mDataSet=mDataSet;
    }
    @Override
    public void onBindViewHolder(Events_MyRecyclerViewAdapter.ViewHolder holder, int position) {
       // holder.vIcon.setImageResource( R.drawable.avatar);


        int drawableID=mContext.getResources().getIdentifier("c"+(position+1),"drawable","com.example.raghavendra.raghavendr_hw9");
        holder.vIcon.setImageResource(drawableID);
        holder.vTitle.setText((String) mDataSet.get(position));

       /* Picasso.with(mContext).load((Integer) movie.get("image")).into(holder.vIcon
                , PicassoPalette.with((String) movie.get("url"), holder.vIcon)
                .use(PicassoPalette.Profile.VIBRANT)
                .intoBackground(holder.mFooterView, PicassoPalette.Swatch.RGB)
                .intoTextColor(holder.vTitle, PicassoPalette.Swatch.BODY_TEXT_COLOR));

*/

    }


    @Override
    public Events_MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.events_cat_cardview, parent, false);
        ViewHolder vhu = new ViewHolder(v);
        return vhu;
    }


    @Override
    public int getItemCount() {
        return 9;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView vIcon;
        public TextView vTitle;
        public TextView vDescription;
        public ImageView vMoreOptions;
        public RatingBar vRatingbar;
        public TextView vRatingText;
        @Bind(R.id.movie_item_footer) View mFooterView;
        public ViewHolder(View itemView) {

            super(itemView);
            vIcon = (ImageView) itemView.findViewById(R.id.img_thumbnail);
            vTitle = (TextView) itemView.findViewById(R.id.tv_movie);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(cardItemClickListener !=null)
                        cardItemClickListener.onCardClick(v,getPosition());
                }
            });

        }
    }

    public interface onCardItemClickListener {
        void onCardClick(View view, int position);
        //void onFavouredClicked(View view, int position);
        //void onNotFavouredClicked(View view,int position);
        //void onMoreOptionsClick(View view, int position);
    }

    public void setOnCardClickListener(final onCardItemClickListener card_itemClickListener){
        this.cardItemClickListener = card_itemClickListener;
    }

}

