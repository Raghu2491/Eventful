package com.example.raghavendra.raghavendr_hw9;

import android.graphics.Bitmap;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.util.LruCache;

import java.util.ArrayList;
import java.util.List;


public class fragmentStatePageAdapter extends FragmentStatePagerAdapter {
    List<String> catData;
    int count;
    private LruCache<String, Bitmap> imgMemoryCache;
    EventsViewPager vp=new EventsViewPager();

    // MovieData movieData=new MovieData();
    public fragmentStatePageAdapter(FragmentManager fm, int size, List<String> obj) {

        super(fm);
        count=size;
        catData=obj;
        catData = new ArrayList<String>(obj);
    }



    @Override
    public Fragment getItem(int position) {

        Fragment frag=null;
        if(position==0)
        {
            //System.out.println("---------->>>>>>>>>>>>>>> Events_RecyclerViewFragment in adapterr"+catData);
            Events_RecyclerViewFragment obj = new Events_RecyclerViewFragment();
            frag = obj.newInstance(1,catData);


        }
        if(position==1)
        {

            //Events_RecyclerViewFragment obj = new Events_RecyclerViewFragment();
            //frag = obj.newInstance(1,catData);


            My_Events obj = new My_Events();
            frag = obj.newInstance(1);

        }

       // return MovieFragment.newInstance((HashMap<String, ?>) movieData.getItem(position));
        return frag;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        /*Locale l = Locale.getDefault();
        HashMap<String, ?> movie = (HashMap<String,?>) movieData.getItem(position);
        String name = (String) movie.get("name");
        return name.toUpperCase(l);*/
        switch(position)
        {
            case 0:
                return "Events";
            case 1:
                return "AroundMe!";


        }
        return null;
    }
}
