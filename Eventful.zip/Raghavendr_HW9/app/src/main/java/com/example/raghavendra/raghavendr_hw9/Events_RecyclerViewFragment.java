package com.example.raghavendra.raghavendr_hw9;


import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.ShareActionProvider;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

//import com.baoyz.widget.PullRefreshLayout;

import com.firebase.client.Firebase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.ButterKnife;

/*import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInBottomAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInBottomXAnimator;
/**
 * Created by Raghavendra on 2/22/2016.
 */

public class Events_RecyclerViewFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private ShareActionProvider mShareActionProvider;
    private Events_MyRecyclerViewAdapter mRecyclerViewAdapter;
    private static final String ARG_SECTION_NUMBER = "section_number";
    protected DrawerLayout drawerlayout;
    private NavigationView navigationView;


    static List<String> catsList;
    public interface OnEachCardItemSelectedListener {
        void OnEachCardSelected(int position);
    }

    OnEachCardItemSelectedListener mListener;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public Events_RecyclerViewFragment() {
        // Required empty public constructor

    }
    public static Events_RecyclerViewFragment newInstance(int sectionNumber,List<String> obj) {
        Events_RecyclerViewFragment fragment = new Events_RecyclerViewFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        catsList=new ArrayList<String>(obj);

        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    ///////Connect here
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,final Bundle savedInstanceState)
    {

        View rootView;
        rootView = inflater.inflate(R.layout.fragment_events__recycler_view, container, false);
        ButterKnife.bind(this, rootView);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.cardList);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new GridLayoutManager(getActivity(),1);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerViewAdapter = new Events_MyRecyclerViewAdapter(getActivity(), catsList);
        //////////////////////////////
        mRecyclerView.setAdapter(mRecyclerViewAdapter);
        //Movies_MovieData movie=new Movies_MovieData();


        mListener = (OnEachCardItemSelectedListener) getContext();

        mRecyclerViewAdapter.setOnCardClickListener(new Events_MyRecyclerViewAdapter.onCardItemClickListener() {
            @Override
            public void onCardClick(View view, int position) {

               // HashMap<String, ?> movie = (HashMap<String, ?>) moviesMovieData.findFirst(position);
                mListener.OnEachCardSelected(position);
            }



        });

        return rootView;
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);

    }

    private class ActionBarCallBack implements ActionMode.Callback {
        int position;

        public ActionBarCallBack(int position) {
            this.position = position;
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            //  mode.getMenuInflater().inflate(R.menu.menu_redundantpopup,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            mode.setTitle((String) catsList.get(this.position));
            return false;
        }
        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int id = item.getItemId();

            return false;
        }

    }

}
