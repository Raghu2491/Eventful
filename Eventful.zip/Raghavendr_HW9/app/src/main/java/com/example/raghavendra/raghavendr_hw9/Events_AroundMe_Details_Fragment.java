package com.example.raghavendra.raghavendr_hw9;

/**
 * Created by Raghavendra on 4/29/2016.
 */import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.ShareActionProvider;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.client.AuthData;
import com.firebase.client.Firebase;
import com.google.android.gms.maps.model.LatLng;
import com.nostra13.universalimageloader.core.ImageLoader;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 *
 * to handle interaction events.
 * Use the {@link EventPage_Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Events_AroundMe_Details_Fragment extends Fragment {

    private static Bitmap icon;
    private static final String ARG_SECTION_NUMBER = "section_number";
    AuthData authData;
    Map<String,?> fb_userdata;
    static int position;
    static HashMap movieData;
    static String free;
    createEventListener cListener;
    directionsListener  dListener;
    static HashMap<String,?> movie;
    Firebase mref;
    private ShareActionProvider mShareActionProvider;
    public Events_AroundMe_Details_Fragment() {
        // Required empty public constructor
    }
    public static Events_AroundMe_Details_Fragment newInstance(int position,HashMap<String, ?> mDataSet,Bitmap ic) {
        Events_AroundMe_Details_Fragment fragment = new Events_AroundMe_Details_Fragment();

        position = position;

        icon=ic;

        movieData = new HashMap(mDataSet);
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }
    public static Events_AroundMe_Details_Fragment newInstance() {
        Events_AroundMe_Details_Fragment fragment = new Events_AroundMe_Details_Fragment();

        position = position;

        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }
    public static Events_AroundMe_Details_Fragment newInstance(int position,List<Map<String, ?>> mDataSet,Bitmap ic) {
        Events_AroundMe_Details_Fragment fragment = new Events_AroundMe_Details_Fragment();

        position = position;
        icon=ic;
        movieData = new HashMap();
        movieData = (HashMap)mDataSet.get(position);
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ////System.out.println("----------->>>>>>>>>>>>>>>>>>> inflating event page on click");

        View  rootView =inflater.inflate(R.layout.event_details, container, false);
        //getMoviesList();
        TextView title = (TextView)rootView.findViewById(R.id.event_title);

        TextView desc = (TextView)rootView.findViewById(R.id.event_description);
        TextView start = (TextView)rootView.findViewById(R.id.start_time);
        TextView end = (TextView)rootView.findViewById(R.id.end_time);
        ImageView Img =  (ImageView)rootView.findViewById(R.id.movie_poster);
        ImageView cover =  (ImageView)rootView.findViewById(R.id.movie_cover);
        cover.setImageResource(R.drawable.default_img);
        if(icon==null)
            Img.setImageResource(R.drawable.default_img);
        else
        {
            //ImageLoader imageLoader = ImageLoader.getInstance();
            //imageLoader.displayImage((String)movieData.get("pic"),Img);
            //Img.setImageBitmap(icon);

        }
        TextView venue = (TextView)rootView.findViewById(R.id.venue);

        title.setText((String) movieData.get("title"));
        desc.setText((String) movieData.get("host"));
        venue.setText((String) movieData.get("place"));
        start.setText((String) movieData.get("starttime"));



       // Button direc = (Button) rootView.findViewById(R.id.directions);
        final Button whois_going = (Button) rootView.findViewById(R.id.whoIsgoing);
        Button interested = (Button) rootView.findViewById(R.id.interested);
        Button direc = (Button) rootView.findViewById(R.id.directions);
        direc.setVisibility(View.GONE);

        Firebase fb4=new Firebase("https://example007.firebaseio.com");
       authData= fb4.getAuth();


        //authData=fb4.getAuth();
        fb_userdata=authData.getProviderData();

        whois_going.setVisibility(View.GONE);

        if(authData.getUid().equals(movieData.get("uid")))
        {
            whois_going.setVisibility(View.VISIBLE);
            interested.setVisibility(View.GONE);

        }
        else
        {

            mref=new Firebase("https://apuroopah9.firebaseio.com/interested");
            Map<String,String> updates=new HashMap<String, String>();
            updates.put("username",(String)fb_userdata.get("displayName"));
            updates.put("profilelink", (String) fb_userdata.get("profileImageURL"));
            mref.child((String) movieData.get("title")).child((String)fb_userdata.get("displayName")).setValue(updates);

        }


        return  rootView;
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // //System.out.println("999999999999999R.menu.menu_fragement_detail"+R.menu.fragment_movie);
        inflater.inflate(R.menu.menu_fragementdetail, menu);
        MenuItem shareItem = menu.findItem(R.id.shareaction);
        //mShareActionProvider= (ShareActionProvider) shareItem.getActionProvider();
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(shareItem);

        Intent intentShare = new Intent(Intent.ACTION_SEND);
        intentShare.setType("text/plain");
        intentShare.putExtra(Intent.EXTRA_TEXT, (String) movie.get("name"));
        mShareActionProvider.setShareIntent(intentShare);



        super.onCreateOptionsMenu(menu, inflater);


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }


    public interface createEventListener{
        public         void createEvent();
    }

    public interface directionsListener{
        public         void getDirections(LatLng location);
    }
}
