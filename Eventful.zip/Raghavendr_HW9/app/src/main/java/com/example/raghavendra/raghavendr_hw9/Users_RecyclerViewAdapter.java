package com.example.raghavendra.raghavendr_hw9;

/**
 * Created by Raghavendra on 3/25/2016.
 */
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v4.util.LruCache;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Users_RecyclerViewAdapter extends RecyclerView.Adapter<Users_RecyclerViewAdapter.ViewHolder> {
    private HashMap<String,?>  mDataSet;
    private Context mContext;
    private onCardClickListener mCardClickListener;
    private LruCache<String, Bitmap> imgMemoryCache;
    public  Bitmap icon;
    public int c;

    public Users_RecyclerViewAdapter(Context myContext, HashMap<String,?> mDataSet){
        this.mContext=myContext;
        this.mDataSet=mDataSet;

        if (imgMemoryCache== null) {
            final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);

            // Use 1/8th of the available memory for this memory cache.
            final int cacheSize = maxMemory / 8;

            imgMemoryCache = new LruCache<String, Bitmap>(cacheSize) {
                @Override
                protected int sizeOf(String key, Bitmap bitmap) {
                    // The cache size will be measured in kilobytes rather than
                    // number of items.
                    return bitmap.getByteCount() / 1024;
                }
            };
        }
    }

    @Override
    public Users_RecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_cardview, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(Users_RecyclerViewAdapter.ViewHolder holder, int position) {
        Map<String, ?> movie = mDataSet;
        // holder.vIcon.setImageResource((Integer) movie.get("id"));
        holder.vTitle.setText((String) movie.get("title"));
        holder.vDescription.setText((String) movie.get("description"));

        String imgUrl = (String) movie.get("url");
        final Bitmap bitmap = imgMemoryCache.get(imgUrl);
        if(bitmap!=null){
            holder.vIcon.setImageBitmap(bitmap);
        }
        else {
            MyImageDownload myImageDownload = new MyImageDownload(holder.vIcon);
            myImageDownload.execute(imgUrl);
        }
        if(!imgUrl.equals("null"))
        {
            // //System.out.println("---------------->>>>>>>>>>>>>>>>>>imgUrl not null ");

            icon = MyUtility.downloadImageusingHTTPGetRequest(imgUrl);
            holder.vIcon.setImageBitmap(icon);
            //System.out.println("---------------->>>>>>>>>>>>>>>>>>img downloaded " + icon);

        }

        if(holder.vIcon==null)
            holder.vIcon.setImageResource(R.drawable.default_img);

    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView vIcon;
        public TextView vTitle;
        public TextView vDescription;
        public ImageView vMoreOptions;

        public ViewHolder(View itemView) {

            super(itemView);
            vIcon = (ImageView) itemView.findViewById(R.id.movieCard);
            vTitle = (TextView) itemView.findViewById(R.id.movietitle);
            vDescription = (TextView) itemView.findViewById(R.id.description);


        }
    }

    public interface onCardClickListener{
        void onCardClick(View view, int position,List<Map<String, ?>> mDataSet, Bitmap img);

    }

    public void setOnCardClickListener(final onCardClickListener mCardClickListener){
        this.mCardClickListener = mCardClickListener;
    }

    private class MyImageDownload extends AsyncTask<String, Void, Bitmap>{
        private WeakReference<ImageView> imageViewWeakReference;
        public MyImageDownload(ImageView img) {
            imageViewWeakReference = new WeakReference<ImageView>(img);
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            Bitmap icon = null;
            for(String url : params) {
                if(!url.equals("null"))
                    icon = MyUtility.downloadImageusingHTTPGetRequest(url);
                if(icon!=null){
                    imgMemoryCache.put(url,icon);
                }


            }
            return icon;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if(imageViewWeakReference!=null && bitmap!=null){
                final ImageView imageView = imageViewWeakReference.get();
                if(imageView!=null){
                    imageView.setImageBitmap(bitmap);
                }
            }
        }
    }
}
