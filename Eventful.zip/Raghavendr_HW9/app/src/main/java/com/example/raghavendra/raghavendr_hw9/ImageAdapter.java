package com.example.raghavendra.raghavendr_hw9;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Raghavendra on 4/19/2016.
 */
public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    static List<String> catsList;
GridView gridView;
    public ImageAdapter(Context c,List<String> obj,View gView ) {

        mContext = c;
        catsList= new ArrayList<String>(obj);
        gridView=(GridView) gView;
    }

    public int getCount() {
        return 9;//mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
      /*  ImageView imageView;

        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(300, 300));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }
        int drawableID=mContext.getResources().getIdentifier("cat"+(position+1),"drawable","com.example.raghavendra.hw8");
        imageView.setImageResource(drawableID);


        return imageView;*/

        LinearLayout layout = new LinearLayout(mContext);
        //layout.setPadding(20,40,20,20);
       // GridView gview = (GridView) convertView.findViewById(R.id.gridview);
        layout.setLayoutParams(new GridView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        layout.setPadding(20, 60, 20,20);

        layout.setOrientation(LinearLayout.VERTICAL);
        int drawableID=mContext.getResources().getIdentifier("cat"+(position+1),"drawable","com.example.raghavendra.raghavendr_hw9");

        ImageView imageView = new ImageView(mContext);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        imageView.setPadding(20, 20, 20,20);

        imageView.setImageResource(drawableID);

        TextView textview = new TextView(mContext);
        textview.setLayoutParams(new LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        textview.setText(catsList.get(position));
       // textview.setText("catsList");
        textview.setTextColor(Color.RED);
       // //System.out.println("---------------->>>>>>>>>>>>>>>>>>view " + drawableID);

        ////System.out.println("---------------->>>>>>>>>>>>>>>>>>textview " + imageView.getDrawable());

        layout.addView(imageView);
        layout.addView(textview);

        return layout;
    }
   /* private Integer[] mThumbIds = {

            R.drawable.comedy,R.drawable.conference,R.drawable.family_fun_kids,R.drawable.festivals_parades,
            R.drawable.music,R.drawable.performing_arts,R.drawable.food,R.drawable.sports,R.drawable.singles_social

    };*/
}