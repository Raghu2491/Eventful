package com.example.raghavendra.raghavendr_hw9;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by Apuroopa on 4/24/2016.
 */
public class DateChangedBroadcastReceiver extends BroadcastReceiver {
    public static int dayOfWeek;
    @Override
    public void onReceive(Context context, Intent intent) {
        Date todaysDate=new Date();
        Calendar calendar=Calendar.getInstance();
        Toast.makeText(context, "(BC received)Date Changed", Toast.LENGTH_LONG).show();
        Log.d("Date changed ", (Integer.toString(calendar.get(Calendar.DAY_OF_WEEK))));
        dayOfWeek=calendar.get(Calendar.DAY_OF_WEEK);

        Intent intent1=new Intent(context,MainActivity.class);
        context.startService(intent1);

        /*

        Do firebase Loading here
         */

    }
}
