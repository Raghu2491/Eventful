package com.example.raghavendra.raghavendr_hw9;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.baoyz.widget.PullRefreshLayout;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInBottomAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInBottomXAnimator;
/**
 * Created by Raghavendra on 3/25/2016.
 */

public class RecyclerViewFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    EventsDataJson movieData=new EventsDataJson();
    PullRefreshLayout layout = null;
    private MyRecyclerViewAdapter mRecyclerViewAdapter;
    private static final String ARG_SECTION_NUMBER = "section_number";

    static String category="";
    static ArrayList<String> catsList;
    public interface OnEachCardSelectedListener{
        void OnEachCardSelected(int position, List<Map<String, ?>> mDataSet, Bitmap icon);
    }

    OnEachCardSelectedListener mListener;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(menu.findItem(R.id.search)==null)
            inflater.inflate(R.menu.menu_fragment_task,menu);

        SearchView search = (SearchView) menu.findItem(R.id.search).getActionView();
/////////Change this---------------------->>>>>>>>>>
        if(search!=null){
            final List<Map<String,?>> movieList = movieData.getMoviesList();
            search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

                @Override
                public boolean onQueryTextSubmit(String query) {
                    String rating_url = EventsDataJson.PHP_SERVER+"movies/rating/"+query;
                    MyDownloadMovieDataCard e = new MyDownloadMovieDataCard(mRecyclerViewAdapter);
                    e.execute(rating_url);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return true;
                }
            });
        }
        MenuItem createEvent =  menu.findItem(R.id.overflo);
        createEvent.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent intent2 = new Intent(getContext(), create_Event.class);
                //intent2.putStringArrayListExtra("cats", catsList);
                intent2.putExtra("cats",catsList);
                startActivity(intent2);

                return true;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        return super.onOptionsItemSelected(item);
    }

    public RecyclerViewFragment() {
        // Required empty public constructor

    }

    public static RecyclerViewFragment newInstance(HashMap<String, ?> sectionNumber) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();

        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    public static RecyclerViewFragment newInstance(int sectionNumber, String categ) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();
        category=categ;
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }
    public static RecyclerViewFragment newInstance(int sectionNumber, String categ, ArrayList<String> categorylist) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();
        category=categ;
        catsList = new ArrayList<String>(categorylist);

        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            mListener =  (OnEachCardSelectedListener)getContext();
        }
        catch(ClassCastException exception){
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setRetainInstance(true);*/
        setHasOptionsMenu(true);
        movieData = new EventsDataJson();
    }
    public boolean isNetworkAvailable(){
        ConnectivityManager cm = (ConnectivityManager)getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if(info!=null && info.isConnected()){
            return true;
        }
        return false;
    }
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {

        final View rootView;
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.cardList);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerViewAdapter = new MyRecyclerViewAdapter(getActivity(), movieData.getMoviesList());
        String movieUrl;
        if(!category.equals("null"))
            movieUrl="https://api.eventful.com/json/events/search?q="+category.trim()+"&l=arizona&app_key=PpsCrSWsFxHZnzJM";
        else
         movieUrl = EventsDataJson.PHP_SERVER ;//category
        if(isNetworkAvailable()) {
            MyDownloadMovieDataCard myDownloadMovieDataCard = new MyDownloadMovieDataCard(mRecyclerViewAdapter);
            //System.out.println("----------->>>>>>>>>>>>>>>>>>> On sending category movieUrl " + movieUrl);

            myDownloadMovieDataCard.execute(movieUrl);

        }

        mRecyclerView.setAdapter(mRecyclerViewAdapter);


        mRecyclerViewAdapter.setOnCardClickListener(new MyRecyclerViewAdapter.onCardClickListener() {
            @Override
            public void onCardClick(View view, int position,List<Map<String, ?>> mDataSet,Bitmap icon) {
                //System.out.println("------------>>>>>>>>>>>>>>>    EVENTS IMAGE " + icon);
                mListener.OnEachCardSelected(position, mDataSet, icon );

            }


        });


        layout = (PullRefreshLayout) rootView.findViewById(R.id.swipeRefreshLayout);
        layout.setOnRefreshListener(new PullRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getFragmentManager().beginTransaction()
                        .add(R.id.container, RecyclerViewFragment.newInstance(1,category))
                        .commit();
                //mRecyclerViewAdapter.notifyItemRangeChanged(0, mRecyclerViewAdapter.getItemCount());
                Toast.makeText(getContext(), "Refreshed", Toast.LENGTH_LONG).show();
                layout.setRefreshing(false);
            }
        });
        layout.setRefreshStyle(PullRefreshLayout.STYLE_MATERIAL);
        itemAnimation();
        adapterAnimation();
        return rootView;
    }
    private void itemAnimation(){
        FlipInBottomXAnimator animator = new FlipInBottomXAnimator();
        animator.setAddDuration(300);
        animator.setRemoveDuration(300);
        mRecyclerView.setItemAnimator(animator);
    }

    private void adapterAnimation(){
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(mRecyclerViewAdapter);
        SlideInBottomAnimationAdapter slideAdapter = new SlideInBottomAnimationAdapter(alphaAdapter);
        slideAdapter.setDuration(1000);
        slideAdapter.setInterpolator(new OvershootInterpolator());
        slideAdapter.setFirstOnly(false);
        mRecyclerView.setAdapter(slideAdapter);
    }

    private class ActionBarCallBack implements ActionMode.Callback {
        int position;

        public ActionBarCallBack(int position) {
            this.position = position;
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.menu_popup,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            HashMap<String,?> movie = (HashMap<String,?>) movieData.getItem(position);
            mode.setTitle((String) movie.get("name"));
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int id = item.getItemId();
/*
            switch (id){

                case R.id.action_delete:
                    List<Map<String,?>> maps = movieData.getMoviesList();
                    JSONObject json = null;
                    HashMap<String,?> movie = (HashMap)maps.get(position);
                    //if(movie!=null){
                    json=new JSONObject(movie);
                    //}
                    final JSONObject finalJson = json;
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            String url = EventsDataJson.PHP_SERVER + "delete";
                            MyUtility.sendHttPostRequest(url, finalJson);
                        }
                    };
                    new Thread(runnable).start();
                    maps.remove(position);
                    mRecyclerViewAdapter.notifyItemRemoved(position);
                    mode.finish();
                    break;
                case R.id.duplicate:
                    movieData.addItem(position+1,(HashMap)(movieData.getItem(position).clone()));
                    mRecyclerViewAdapter.notifyItemInserted(position + 1);
                    mode.finish();
                    break;
                default:
                    break;
            }*/
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
    }

    private class MyDownloadMovieDataCard extends AsyncTask<String, Void, EventsDataJson> {
        private final WeakReference<MyRecyclerViewAdapter> adapterWeakReference;
        public MyDownloadMovieDataCard(MyRecyclerViewAdapter adapter) {
            adapterWeakReference = new WeakReference<MyRecyclerViewAdapter>(adapter);
        }

        @Override
        protected EventsDataJson doInBackground(String... params) {

            EventsDataJson threadMovieData = new EventsDataJson();
            for(String url: params){
                threadMovieData.downloadMovieDataFromJson(url);
            }
            return threadMovieData;
        }

        @Override
        protected void onPostExecute(EventsDataJson s) {
            movieData.moviesList.clear();
            for(int i=0;i<s.getSize();i++){
                movieData.moviesList.add(s.moviesList.get(i));
            }
            if(adapterWeakReference!=null){
                final MyRecyclerViewAdapter adapter = adapterWeakReference.get();
                if(adapter!=null){
                    adapter.notifyDataSetChanged();
                }
            }
        }
    }

   /* private class MyDownloadMovieDetail extends AsyncTask<String, Void, HashMap>{
        private WeakReference<OnEachCardSelectedListener> listenerWeakReference;

        public MyDownloadMovieDetail(OnEachCardSelectedListener listener) {
            listenerWeakReference = new WeakReference<OnEachCardSelectedListener>(listener);
        }

        @Override
        protected HashMap doInBackground(String... params) {
            String detailJson ="";
            HashMap<String,?> movieDetail = new HashMap<>();
            for(String url : params){
                //detailJson = MyUtility.downloadJSONusingHTTPGetRequest(url);
                movieDetail = movieData.downloadMovieDetailFromJson(url);
            }
            //movieDetail = movieData.downloadMovieDetailFromJson(detailJson);
            return movieDetail;
        }

        @Override
        protected void onPostExecute(HashMap hashMap) {
            OnEachCardSelectedListener listener = listenerWeakReference.get();
            if(listener!=null){
                listener.OnEachCardSelected();
                //mRecyclerViewAdapter.notifyDataSetChanged();
            }
        }
    }*/


}
