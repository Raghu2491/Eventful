package com.example.raghavendra.raghavendr_hw9;


import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.firebase.client.AuthData;
import com.firebase.client.Firebase;

import java.util.ArrayList;

/**
 * Created by Raghavendra on 3/29/2016.
 */
public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private Fragment mContent;
    //MovieData movieData= new MovieData();
    private NavigationView navigationView;
    protected DrawerLayout drawerLayout;
    protected Toolbar toolbar;

    LoginActivity lg;
    AuthData ad;
    String token;

    static ArrayList<String> catsList;
    private EventsDataJson movieDataJson = new EventsDataJson();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        /////////////////////////ADDED----------------------->>>>>>>>>>>>>>>
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open_drawer,R.string.close_drawer){
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };

        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();



        ////////////////////////dovvnload CATEGORIES --------------->>>>>>>>>>>>>>>>

        catsList = new ArrayList<String>();

        if (isNetworkAvailable()) {

            //////System.out.println("---------------------<<<<<<<Network is available");
            String movieUrl = "http://api.eventful.com/json/categories/list?&app_key=PpsCrSWsFxHZnzJM";

            MyDownloadMovieDataCard myDownloadMovieDataCard = new MyDownloadMovieDataCard(catsList);
            myDownloadMovieDataCard.execute(movieUrl);
        }
        ////////////////////////     --------------->>>>>>>>>>>>>>>>

        //HashMap<String, ?> movie = (HashMap<String, ?>) movieData.getItem(1);
        //....................>>>>>>>>>>>> REVERT
       // if(savedInstanceState!=null)
         //   mContent = getSupportFragmentManager().getFragment(savedInstanceState, "mContent");
       // else
            mContent = App_CoverPage_Fragment.newInstance(0);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, mContent)
                .commit();
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info != null && info.isConnected()) {
            return true;
        }
        return false;
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(mContent.isAdded())
            getSupportFragmentManager().putFragment(outState, "mContent", mContent);
    }
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                //////System.out.println("---------->>>>>>>>>> item1");
                Intent intentV = new Intent(this, EventsViewPager.class);
                intentV.putExtra("cat", catsList);
                startActivity(intentV);
                break;
            case R.id.item2:

                //////System.out.println("  ------------------>>>>>>> Main categorylist "+catsList);

                Intent intent2 = new Intent(this, create_Event.class);
                //intent2.putStringArrayListExtra("cats", catsList);
                intent2.putExtra("cats",catsList);
                startActivity(intent2);
                break;
            case R.id.item3:

               // Intent intent = new Intent(this, Movies_MainActivity.class);
               // startActivity(intent);

                break;


            case R.id.item4:
                //////System.out.println("---------------->>>> on sign out");
                Intent intent1 = new Intent(this, LogoutActivity.class);
                startActivity(intent1);

                         break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    private class MyDownloadMovieDataCard extends AsyncTask<String, Void, EventsDataJson> {
        //  private final WeakReference<fragmentStatePageAdapter> adapterWeakReference;
        public MyDownloadMovieDataCard(ArrayList<String> myCatsList) {
            //   adapterWeakReference = new WeakReference<fragmentStatePageAdapter>(adapter);
        }

        @Override
        protected EventsDataJson doInBackground(String... params) {

            EventsDataJson threadMovieData = new EventsDataJson();
            for (String url : params) {
                threadMovieData.downloadCatDataFromJson(url);
            }
            return threadMovieData;
        }

        @Override
        protected void onPostExecute(EventsDataJson s) {

            ////////System.out.println(" onPostExecute is: --------------> " + s.categories);
            catsList = new ArrayList<String>(s.categories);
            //////System.out.println(" onPostExecute is: --------------> " + catsList);


        }
    }
}


