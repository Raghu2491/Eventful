package com.example.raghavendra.raghavendr_hw9;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.*;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class create_Event extends AppCompatActivity {
     Firebase mRef;
    //Firebase.
    public final String APP_TAG = "MyCustomApp";
    public String photoFileName = "photo.jpg";
    public final static int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 235;// 1034;
     static String base64Image;
    static boolean createBool;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ////System.out.println("  ------------------>>>>>>> CreateEvent called");
        Firebase.setAndroidContext(this);
        mRef = new Firebase("https://apuroopah9.firebaseio.com/CreateEventsData");
        setContentView(R.layout.fragment_create_event);
       final EditText eventTitle =(EditText)findViewById(R.id.EtitleText);
        final EditText date =(EditText)findViewById(R.id.date);
        final EditText start_time =(EditText)findViewById(R.id.start);
        final EditText stop_time =(EditText)findViewById(R.id.stop);
        final EditText WhereText =(EditText)findViewById(R.id.WhereText);
        //spinner2
        Spinner cateory = (Spinner) findViewById(R.id.spinner2);

        ArrayList<String> arraySpinner = new ArrayList<String>(getIntent().getStringArrayListExtra("cats"));

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        cateory.setAdapter(adapter);
        Button create = (Button) findViewById(R.id.Create);
        Button capture = (Button) findViewById(R.id.camera);

        Map<String, String> updates ;
       create.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               String title = eventTitle.getText().toString();
              // mRef.update({ title: { first: 'Fred', last: 'Flintstone' }});
               Map<String, String> updates = new HashMap<String, String>();
               updates.put("date", date.getText().toString());
               updates.put("start_time", start_time.getText().toString());
               updates.put("stop_time", stop_time.getText().toString());
               updates.put("WhereText", WhereText.getText().toString());
               updates.put("pic", base64Image);
               mRef.child(title).setValue(updates);

           }
       });
        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onLaunchCamera(v);


            }
        });

    }

    public void onLaunchCamera(View view) {
       // //System.out.println("  ------------------>>>>>>> onLaunchCamera called");

        // create Intent to take a picture and return control to the calling application
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, getPhotoFileUri(photoFileName)); // set the image file name

        // If you call startActivityForResult() using an intent that no app can handle, your app will crash.
        // So as long as the result is not null, it's safe to use the intent.
        if (intent.resolveActivity(getPackageManager()) != null) {
            // Start the image capture intent to take photo
            Boolean permission = hasPermissionInManifest( this,Manifest.permission.CAMERA);

            //.................................................................
            // Here, thisActivity is the current activity
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
               // //System.out.println("  ------------------>>>>>>> onLaunchCamera NOOOO permission ");

                // Should we show an explanation?
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.CAMERA)) {

                    // Show an expanation to the user *asynchronously* -- don't block
                    // this thread waiting for the user's response! After the user
                    // sees the explanation, try again to request the permission.
                   // //System.out.println("  ------------------>>>>>>> onLaunchCamera explanation ");


                } else {

                    // No explanation needed, we can request the permission.

                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.CAMERA},
                            CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
                  //  //System.out.println("  ------------------>>>>>>> onLaunchCamera NOOOO explanation");

                }
            }

            int permissionCheck = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.CAMERA);//returns -1 - denied
         //   //System.out.println("  ------------------>>>>>>> onLaunchCamera permission requested "+permissionCheck);

            if(permissionCheck!=-1);
               startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Uri takenPhotoUri = getPhotoFileUri(photoFileName);
                // by this point we have the camera photo on disk
                Bitmap takenImage = BitmapFactory.decodeFile(takenPhotoUri.getPath());
                // Load the taken image into a preview
                ImageView ivPreview = (ImageView) findViewById(R.id.Eimage);
                ivPreview.setImageBitmap(takenImage);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                takenImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] bytes = baos.toByteArray();
                 base64Image = Base64.encodeToString(bytes, Base64.DEFAULT);

                // we finally have our base64 string version of the image, save it.
                mRef.child("pic").setValue(base64Image);
            } else { // Result was a failure
                Toast.makeText(this, "Picture wasn't taken!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public boolean hasPermissionInManifest(Context context, String permissionName) {
        final String packageName = context.getPackageName();
        try {
            final PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(packageName, PackageManager.GET_PERMISSIONS);
            final String[] declaredPermisisons = packageInfo.requestedPermissions;
            if (declaredPermisisons != null && declaredPermisisons.length > 0) {
                for (String p : declaredPermisisons) {
                    if (p.equals(permissionName)) {
                        return true;
                    }
                }
            }
        } catch (PackageManager.NameNotFoundException e) {

        }
        return false;
    }
        // Returns the Uri for a photo stored on disk given the fileName
    public Uri getPhotoFileUri(String fileName) {
        // Only continue if the SD Card is mounted
        if (isExternalStorageAvailable()) {
            // Get safe storage directory for photos
            // Use `getExternalFilesDir` on Context to access package-specific directories.
            // This way, we don't need to request external read/write runtime permissions.
            File mediaStorageDir = new File(
                    getExternalFilesDir(Environment.DIRECTORY_PICTURES), APP_TAG);

            // Create the storage directory if it does not exist
            if (!mediaStorageDir.exists() && !mediaStorageDir.mkdirs()){
                Log.d(APP_TAG, "failed to create directory");
            }
            // Return the file target for the photo based on filename
            return Uri.fromFile(new File(mediaStorageDir.getPath() + File.separator + fileName));
        }
        return null;
    }
    // Returns true if external storage for photos is available
    private boolean isExternalStorageAvailable() {
        String state = Environment.getExternalStorageState();
        return state.equals(Environment.MEDIA_MOUNTED);
    }
}
