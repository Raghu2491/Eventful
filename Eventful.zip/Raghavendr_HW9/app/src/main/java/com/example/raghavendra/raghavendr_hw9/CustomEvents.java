package com.example.raghavendra.raghavendr_hw9;

//pojo class
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

@JsonIgnoreProperties({ "pic","date" })
public class CustomEvents implements Serializable{

    //String creator, eventName, Place,  uid;
    //String date,place,starttime,pic,uid,host,title;

    String host,place,starttime,title,uid;
    float rating;

    public CustomEvents() {
        //System.out.println(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<< ");
    }
    public String getHost(){
        return this.host;
    }
    public void setHost(String host){
        this.host=host;
    }




    public String getPlace() {
        return this.place;
    }

    public void setPlace(String place) {
        this.place = place;
    }


    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public void getTitle(String title) {
        this.title=title;
    }

    public String getTitle() {
        return title;
    }


    public String getUid() {
        return this.uid;
    }

    public void setUid(String uid){
        this.uid=uid;
    }


}
