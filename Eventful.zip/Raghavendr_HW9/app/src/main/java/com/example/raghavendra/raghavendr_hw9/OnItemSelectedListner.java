package com.example.raghavendra.raghavendr_hw9;

import android.view.View;

import java.util.HashMap;

/**
 * Created by Raghavendra on 4/16/2016.
 */
public interface OnItemSelectedListner {
    public void onItemSelected(HashMap<String, ?> movie, View sharedImaged);
}
