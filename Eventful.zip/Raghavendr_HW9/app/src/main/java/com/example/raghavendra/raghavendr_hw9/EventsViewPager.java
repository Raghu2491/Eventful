package com.example.raghavendra.raghavendr_hw9;

/**
 * Created by Raghavendra on 4/16/2016.
 */
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventsViewPager extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,OnItemSelectedListner,
        Events_RecyclerViewFragment.OnEachCardItemSelectedListener,My_Events.OnEachCardSelectedListener
        {
    EventsDataJson movieData = null;
    fragmentStatePageAdapter fragmentStatePagerAdapter;
    android.support.v4.view.ViewPager viewPager;
    private NavigationView navigationView;
    protected DrawerLayout drawerLayout;
    protected TabLayout tabLayout;
            protected Toolbar toolbar;
            static ArrayList<String> catsList;
    //////////////////FOR GRIDVIEW

    ////////////////// for generic events list

    @Override
    public void OnEachCardSelected(int position)

    {
        Intent intentV = new Intent(this, EventsList.class);
        intentV.putExtra("category", catsList.get(position));
        intentV.putExtra("categoryList", catsList);
        startActivity(intentV);

    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_viewpager);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // ActionBar actionBar = getSupportActionBar();
        ActionBar actionBar=getSupportActionBar();

        //tab1.setTabListener(this);

        actionBar.setDisplayHomeAsUpEnabled(true);

        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open_drawer,R.string.close_drawer){
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };

        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        catsList =  new ArrayList<String>(getIntent().getStringArrayListExtra("cat"));
        ////System.out.println("---------->>>>>>>>>>setAdapter  item1"+catsList);

        fragmentStatePagerAdapter = new fragmentStatePageAdapter(getSupportFragmentManager(),2 , catsList);
       // String movieUrl = "http://api.eventful.com/json/categories/list?&app_key=PpsCrSWsFxHZnzJM" ;

        viewPager = (android.support.v4.view.ViewPager) findViewById(R.id.pager);
        viewPager.setAdapter(fragmentStatePagerAdapter);

        viewPagerAnimation();

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ////System.out.println("---------->>>>>>>>>>FloatingActionButton  Snackbar");

                Snackbar.make(findViewById(R.id.Coordinate), "Select a category to view events", Snackbar.LENGTH_LONG).show();

            }
        });

    }

    private void viewPagerAnimation() {


        viewPager.setPageTransformer(false, new android.support.v4.view.ViewPager.PageTransformer() {
            private static final float MIN_SCALE = 0.85f;
            private static final float MIN_ALPHA = 0.5f;

            @Override
            public void transformPage(View view, float position) {
                int pageWidth = view.getWidth();
                int pageHeight = view.getHeight();

                if (position < -1) {
                    view.setAlpha(0);

                } else if (position <= 1) {
                    // Modify the default slide transition to shrink the page as well
                    float scaleFactor = Math.max(MIN_SCALE, 1 - Math.abs(position));
                    float vertMargin = pageHeight * (1 - scaleFactor) / 2;
                    float horzMargin = pageWidth * (1 - scaleFactor) / 2;
                    if (position < 0) {
                        view.setTranslationX(horzMargin - vertMargin / 2);
                    } else {
                        view.setTranslationX(-horzMargin + vertMargin / 2);
                    }

                    // Scale the page down (between MIN_SCALE and 1)
                    view.setScaleX(scaleFactor);
                    view.setScaleY(scaleFactor);

                    // Fade the page relative to its size.
                    view.setAlpha(MIN_ALPHA +
                            (scaleFactor - MIN_SCALE) /
                                    (1 - MIN_SCALE) * (1 - MIN_ALPHA));

                } else {
                    view.setAlpha(0);
                }
            }
        });
    }



    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                break;
            case R.id.item2:
                EventsViewPager.this.tabLayout.setVisibility(View.GONE);
                FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
                    fab.setVisibility(View.GONE);
                Intent intent2 = new Intent(this, create_Event.class);
                //intent2.putStringArrayListExtra("cats", catsList);
                intent2.putExtra("cats",catsList);
                startActivity(intent2);

                break;
            case R.id.item3:
               // Intent intent = new Intent(this, Movies_MainActivity.class);
               // startActivity(intent);
                break;
            case R.id.item4:
                //System.out.println("---------------->>>> on sign out");
                Intent intent1 = new Intent(this, LogoutActivity.class);
                startActivity(intent1);
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onItemSelected(HashMap<String, ?> movie, View sharedImage) {

    }

            @Override
            public void OnEachCardSelected(int position, HashMap<String, ?> movie, View view) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.pager_container, Events_AroundMe_Details_Fragment.newInstance(position, movie,null))
                        .addToBackStack(null)
                        .commit();
            }
        }
