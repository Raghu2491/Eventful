package com.example.raghavendra.raghavendr_hw9;

/**
 * Created by Raghavendra on 3/25/2016.
 */
//import android.support.multidex.MultiDexApplication;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventsDataJson {

    List<Map<String,?>> moviesList;
    List<String> categories;
    protected static final String PHP_SERVER = "https://api.eventful.com/json/events/search?l=arizona&app_key=PpsCrSWsFxHZnzJM";
    public List<Map<String, ?>> getMoviesList() {
        return moviesList;
    }
    public List<String> getCatList() {
        return categories;
    }

    public int getSize(){
        return moviesList.size();
    }

    public HashMap getItem(int i){
        if (i >=0 && i < moviesList.size()){
            return (HashMap) moviesList.get(i);
        } else return null;
    }

    public String getcat(int i){
        if (i >=0 && i < categories.size()){
            return  categories.get(i);
        } else return null;
    }


    public EventsDataJson(){
        moviesList = new ArrayList<Map<String,?>>();
        categories = new ArrayList<String>();
    }

    public void downloadMovieDataFromJson(String jsonStringUrl){
        String name="";
        String description="";
        String city="";
        String state="";
        String venue="";
        double latitude, longitude;
        //double rating=0.0;
        String url="";
        String Imgurl="";
        String id="";
        String start_time="";
        String stop_time="";

        String image="";
        //String length="";
        //String year="";
        JSONObject movieJsonObj;
        moviesList = new ArrayList<Map<String,?>>();
        try {
            String jsonString = MyUtility.downloadJSONusingHTTPGetRequest(jsonStringUrl);

            JSONObject jObj = new JSONObject(jsonString);
            JSONObject result = jObj.getJSONObject("events");

//JSONObject jb = new JSONObject(response);
            JSONArray jr = result.getJSONArray("event");
            for(int i=0;i<jr.length();i++) {
                JSONObject jb1 = jr.getJSONObject(i);
                name = jb1.getString("title");
                image=name;
                start_time = jb1.getString("start_time");
                description = jb1.getString("description");
                String regx = "'</p><br><strong></strong>?_";

                    description = description.replace("<p>", "");
                    description = description.replace("<br>", "");
                description = description.replace("</p>", "");
                description = description.replace("<strong>", "");
                description = description.replace("</strong>", "");


                latitude = jb1.getDouble("latitude");
                longitude = jb1.getDouble("longitude");
                venue = jb1.getString("venue_address");
                state = jb1.getString("region_name");
                city = venue+" " + jb1.getString("city_name")+state;
                stop_time = jb1.getString("stop_time");
                //System.out.println(" title ------------------>>>>>>> " + name);

                Imgurl = jb1.getString("image");
                id = jb1.getString("id");

               // Log.i("img.......", Imgurl);
                if(!Imgurl.equals("null"))
                {


                    JSONObject jImg = new JSONObject(Imgurl);
                    if(jImg!=null)
                    {
                       // //System.out.println(" obj ------------------>>>>>>> " + jImg);

                        JSONObject med = jImg.getJSONObject("medium");
                       // //System.out.println(" obj ------------------>>>>>>> " + med);
                       Imgurl = med.getString("url");

                       if(! Imgurl.contains("http:"))
                       {
                           Imgurl="http:"+Imgurl;
                       }
                     //   //System.out.println(" url ------------------>>>>>>> " + Imgurl);

                    }
                }


                moviesList.add(createMovie(name, description,Imgurl,image,id,city,start_time,stop_time,latitude,longitude));
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }



    public void downloadCatDataFromJson(String jsonStringUrl){
        String name="";
        String description="";
        String url="";
        String Imgurl="";
        String id="";
        //String director="";
        //String stars="";
        String image="";
        //String length="";
        //String year="";
        JSONObject movieJsonObj;
        moviesList = new ArrayList<Map<String,?>>();
        try {
            String jsonString = MyUtility.downloadJSONusingHTTPGetRequest(jsonStringUrl);

            if(!jsonString.equals("null")) {
                JSONObject jObj = new JSONObject(jsonString);

                JSONArray jCat = jObj.getJSONArray("category");
                for (int j = 0; j < jCat.length(); j++) {
                    JSONObject jc = jCat.getJSONObject(j);
                    String category = jc.getString("name");
                    id = jc.getString("id");

                    int indexOfLast = category.lastIndexOf("&");
                    String newString = category;
                    if (indexOfLast >= 0) newString = newString.substring(0, indexOfLast);
                     Log.i("refined.......", newString);
                    categories.add(newString);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
    private HashMap createMovie(String name, String description,String ImgUrl,String image,String id,String city,String start_time
                                ,String stop_time,Double lat,Double lon){//, String id, double rating,String url, String stars,String director, String year, String length, String image) {

        HashMap movie = new HashMap();
        movie.put("title", name);
        movie.put("description", description);
        movie.put("url",ImgUrl);
        movie.put("image",image);
        movie.put("id",id);
        movie.put("city",city);
        movie.put("start_time",start_time);
        movie.put("stop_time",stop_time);
        movie.put("latitude", lat);
        movie.put("longitude", lon);
       /* movie.put("year",year);
        movie.put("length",length);
        movie.put("image",image);*/
        return movie;
    }


    public HashMap<String,?> downloadMovieDetailFromJson(String jsonStringUrl) {
        String name = "";
        String description = "";
        //double rating = 0.0;
        String url = "";
        /*String id = "";
        String director = "";
        String stars = "";
        String length = "";
        String year = "";*/
        JSONObject movieJsonObj;
        moviesList = new ArrayList<Map<String, ?>>();
        try {
            String jsonString = MyUtility.downloadJSONusingHTTPGetRequest(jsonStringUrl);
            JSONArray movieJsonArray = new JSONArray(jsonString);
            if(movieJsonArray!=null) {
                for (int i = 0; i < movieJsonArray.length(); i++) {
                    movieJsonObj = (JSONObject) movieJsonArray.get(i);
                    if (movieJsonObj != null) {
                        name = (String) movieJsonObj.get("title");
                        description = (String) movieJsonObj.get("description");
                        url = (String) movieJsonObj.get("url");
                       /* id = (String) movieJsonObj.get("id");
                        rating = movieJsonObj.getDouble("rating");
                        stars = (String) movieJsonObj.get("stars");
                        director = (String) movieJsonObj.get("director");
                        year = (String) movieJsonObj.get("year");*/
                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HashMap<String,?> movie = createMovieDetail(name, description,url,"url");//, id, rating, url, stars, director, year, length);
        return movie;

    }


    private HashMap createMovieDetail(String name, String description,String Imgurl,String city){//, String id, double rating,String url, String stars,String director, String year,String length) {
        HashMap movie = new HashMap();
        movie.put("title", name);
        movie.put("description", description);
        movie.put("url",Imgurl);

        /*movie.put("stars", stars);
        movie.put("director", director);
        movie.put("length",length);
        movie.put("year",year);*/
        return movie;
    }

    public void addItem(int position, Map item){
        final JSONObject json;
        String newId = (String)item.get("id")+"_new";

        if(item!=null){
            item.put("id", newId);
            json=new JSONObject(item);
        }
        else json=null;
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                String url = PHP_SERVER + "add";
                MyUtility.sendHttPostRequest(url, json);
            }
        };
        new Thread(runnable).start();
        moviesList.add(position,item);
    }
}
