package com.example.raghavendra.raghavendr_hw9;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.firebase.client.Firebase;
import com.firebase.client.Query;
import com.firebase.ui.FirebaseRecyclerAdapter;
import com.github.florent37.picassopalette.PicassoPalette;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.squareup.picasso.Picasso;
//import com.nostra13.universalimageloader.core.ImageLoader;


public class My_EventsFirebaseAdapter extends FirebaseRecyclerAdapter<CustomEvents,My_EventsFirebaseAdapter.MovieViewHolder> {


    private Context mContext;
    private static onCardClickListener mCardClickListener;
    Firebase mref;
    public String uid;

    public My_EventsFirebaseAdapter(Class<CustomEvents> modelClass, int modelLayout,
                                    Class<MovieViewHolder> holder, Query ref, Context context) {

        super(modelClass, modelLayout, holder, ref);

        this.mContext = context;

    }

    @Override
    protected void populateViewHolder(MovieViewHolder movieViewHolder, CustomEvents customEvents, int i) {

        //TODO: Populate viewHolder by setting the customEvents attributes to cardview fields
        //movieViewHolder.nameTV.setText(customEvents.getName());
        //movieViewHolder.vIcon.setImageResource((Integer) customEvents.get("image"));

        customEvents = getItem(i);
        movieViewHolder.vTitle.setText(customEvents.getTitle());

        movieViewHolder.vDescription.setText(customEvents.getPlace());

        uid=customEvents.getUid();


        //ImageLoader imageLoader = ImageLoader.getInstance();
        //imageLoader.displayImage(customEvents.getPic(),movieViewHolder.vIcon);

      /*  Picasso.with(mContext).load(customEvents.getEventName()).into(movieViewHolder.vIcon
                , PicassoPalette.with(customEvents.getEventName(), movieViewHolder.vIcon)
                .use(PicassoPalette.Profile.MUTED_DARK)
                .intoBackground(movieViewHolder.vDescription)
                .intoBackground(movieViewHolder.vDescription)
                .use(PicassoPalette.Profile.VIBRANT)
                .intoBackground(movieViewHolder.vTitle, PicassoPalette.Swatch.RGB)
                .intoTextColor(movieViewHolder.vTitle, PicassoPalette.Swatch.BODY_TEXT_COLOR));*/

    }

    //TODO: Populate ViewHolder and add listeners.
    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        public ImageView vIcon;
        public TextView vTitle;
        public TextView vDescription;
        public ImageView vMoreOptions;
        public RatingBar vRatingbar;
        public TextView vRatingText;

        public MovieViewHolder(View v) {
            super(v);
            vIcon = (ImageView) itemView.findViewById(R.id.movieCard);
            vTitle = (TextView) itemView.findViewById(R.id.movietitle);
            vDescription = (TextView) itemView.findViewById(R.id.description);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCardClickListener != null)
                        mCardClickListener.onCardClick(vIcon, getAdapterPosition());
                }
            });


        }

    }
    public interface onCardClickListener {
        void onCardClick(View view, int position);


    }

    public void setOnCardClickListener(final onCardClickListener mCardClickListener1) {
        mCardClickListener = mCardClickListener1;
    }

}




