package com.example.raghavendra.raghavendr_hw9;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.ShareActionProvider;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.Toast;

import com.baoyz.widget.PullRefreshLayout;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.HashMap;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInBottomAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInBottomXAnimator;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link My_Events#newInstance} factory method to
 * create an instance of this fragment.
 */
public class My_Events extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    CustomEvents customEventsData =new CustomEvents();
    PullRefreshLayout layout = null;
    private My_EventsFirebaseAdapter mRecyclerViewAdapter;
    final Firebase mRef = new Firebase("https://apuroopah9.firebaseio.com/CreateEventsData");
    private static final String ARG_SECTION_NUMBER = "section_number";


    public interface OnEachCardSelectedListener{
        void OnEachCardSelected(int position, HashMap<String,?> movie,View view);
    }

    OnEachCardSelectedListener mListener;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public My_Events() {
        // Required empty public constructor
    }

    public static My_Events newInstance(HashMap<String, ?> sectionNumber) {

        My_Events fragment = new My_Events();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    public static My_Events newInstance(int sectionNumber) {
        My_Events fragment = new My_Events();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            mListener =  (OnEachCardSelectedListener)getContext();
        }
        catch(ClassCastException exception){
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setRetainInstance(true);*/
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {

        final View rootView;
        // Inflate the layout for this fragment
        final Firebase mRef2 = new Firebase("https://apuroopah9.firebaseio.com/CreateEventsData");
        rootView = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.cardList);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        // mRecyclerViewAdapter = new MyRecyclerViewAdapter(getActivity(), customEventsData.getMoviesList());

        mRecyclerViewAdapter = new My_EventsFirebaseAdapter(CustomEvents.class,R.layout.fragment_cardview, My_EventsFirebaseAdapter.MovieViewHolder.class,mRef,getContext());
        mRecyclerView.setAdapter(mRecyclerViewAdapter);
        itemAnimation();
        adapterAnimation();

        layout = (PullRefreshLayout) rootView.findViewById(R.id.swipeRefreshLayout);
        layout.setOnRefreshListener(new PullRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mRecyclerViewAdapter.notifyItemRangeChanged(0, mRecyclerViewAdapter.getItemCount());
                Toast.makeText(getContext(), "Refreshed", Toast.LENGTH_LONG).show();
                layout.setRefreshing(false);
            }
        });
        layout.setRefreshStyle(PullRefreshLayout.STYLE_MATERIAL);

        mRecyclerViewAdapter.setOnCardClickListener(new My_EventsFirebaseAdapter.onCardClickListener() {
            @Override
            public void onCardClick(final View view, final int position) {
                customEventsData = mRecyclerViewAdapter.getItem(position);
                //System.out.println("--------->mref2 " + mRef2 +" title id "+customEventsData.getTitle());
                //Another way
                //pass CustomEvents customEventsData to the OnEachCardSelected as an argument and later
                //extract from the bundle in MovieDetailFragment
                String id =  customEventsData.getUid();
                mRef2.child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        HashMap<String, ?> movie = (HashMap<String, ?>) dataSnapshot.getValue();
                        //System.out.println(">>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<" + dataSnapshot.getValue());
                        //  ImageView saredImg = (ImageView) view.findViewById(R.id.movieIconCard);
                        mListener.OnEachCardSelected(position, movie, view);
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });

            }


        });

        return rootView;
    }
    private void itemAnimation(){
        FlipInBottomXAnimator animator = new FlipInBottomXAnimator();
        animator.setAddDuration(300);
        animator.setRemoveDuration(300);
        mRecyclerView.setItemAnimator(animator);
    }

    private void adapterAnimation(){
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(mRecyclerViewAdapter);
        SlideInBottomAnimationAdapter slideAdapter = new SlideInBottomAnimationAdapter(alphaAdapter);
        slideAdapter.setDuration(1000);
        slideAdapter.setInterpolator(new OvershootInterpolator());
        slideAdapter.setFirstOnly(false);
        mRecyclerView.setAdapter(slideAdapter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mRecyclerViewAdapter.cleanup();
    }


}
