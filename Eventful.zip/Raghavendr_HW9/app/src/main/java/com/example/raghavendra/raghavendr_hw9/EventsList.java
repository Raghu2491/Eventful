package com.example.raghavendra.raghavendr_hw9;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EventsList extends AppCompatActivity implements RecyclerViewFragment.OnEachCardSelectedListener ,EventPage_Fragment.createEventListener, EventPage_Fragment.directionsListener{

    static String category;
    static ArrayList<String> categorylist;

   /*
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(menu.findItem(R.id.search)==null)
            inflater.inflate(R.menu.menu_fragment_task,menu);

        SearchView search = (SearchView) menu.findItem(R.id.search).getActionView();
/////////Change this---------------------->>>>>>>>>>
       /* if(search!=null){
            final List<Map<String,?>> movieList = movieData.getMoviesList();
            search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

                @Override
                public boolean onQueryTextSubmit(String query) {
                    String rating_url = EventsDataJson.PHP_SERVER+"movies/rating/"+query;
                    MyDownloadMovieDataCard e = new MyDownloadMovieDataCard(mRecyclerViewAdapter);
                    e.execute(rating_url);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return true;
                }
            });
        }
        MenuItem createEvent =  menu.findItem(R.id.overflo);
        createEvent.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent intent2 = new Intent(this, create_Event.class);
                //intent2.putStringArrayListExtra("cats", catsList);
                intent2.putExtra("cats",categorylist);
                startActivity(intent2);

                return true;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_list);
        category =  getIntent().getStringExtra("category");
        categorylist=new ArrayList<>(getIntent().getStringArrayListExtra("categoryList"));
        Toolbar mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);

        getSupportActionBar().setTitle(category);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ElistContainer, RecyclerViewFragment.newInstance(1, category,categorylist))
                .commit();
    }

    @Override
    public void OnEachCardSelected(int position, List<Map<String, ?>> mDataSet, Bitmap icon) {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ElistContainer, EventPage_Fragment.newInstance(position, mDataSet, icon))
                .addToBackStack(null)
                .commit();

    }
    @Override
    public void createEvent()
    {
        //System.out.println("----------->>>>>>>>>>>>>>>>>>> EventsViewPager CreateEvent ");
        Intent intent = new Intent(this, create_Event.class);
        intent.putStringArrayListExtra("cats", categorylist);
        startActivity(intent);
    }
    @Override
    public void getDirections(LatLng location)
    {

        getSupportFragmentManager().beginTransaction()
                .add(R.id.ElistContainer, FragmentGoogleMap.newInstance(location))
                .addToBackStack(null)
                .commit();
    }


}
