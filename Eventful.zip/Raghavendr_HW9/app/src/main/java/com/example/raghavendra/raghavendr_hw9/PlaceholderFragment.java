package com.example.raghavendra.raghavendr_hw9;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Point;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Raghavendra on 4/16/2016.
 */
public class PlaceholderFragment extends Fragment {



    private static final String ARG_SECTION_NUMBER = "section_number";
    private int choice;
    EventsDataJson movieData=new EventsDataJson();
    List<Map<String,?>> moviesList;
    static List<String> catsList;
    private OnItemSelectedListner mListener;
    onItemClickListener mGridViewListener;
    ImageView eImage;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;



    public static PlaceholderFragment newInstance(int sectionNumber,List<String> obj) {
        PlaceholderFragment fragment = new PlaceholderFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        catsList=new ArrayList<String>(obj);
        return fragment;
    }

    public PlaceholderFragment() {
        //moviesList = new MovieData().getMoviesList();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setRetainInstance(true);*/
        setHasOptionsMenu(true);
        movieData = new EventsDataJson();
    }
    public boolean isNetworkAvailable(){
        ConnectivityManager cm = (ConnectivityManager)getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if(info!=null && info.isConnected()){
            return true;
        }
        return false;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        choice = getArguments().getInt(ARG_SECTION_NUMBER);

        View rootView = inflater.inflate(R.layout.fragment_grid, container, false);

        // GridLayout gridLayout = (GridLayout) rootView.findViewById(R.id.gridlayout);
        //gridLayout.setUseDefaultMargins(true);

        GridView gridview = (GridView) rootView.findViewById(R.id.gridview);
        gridview.setAdapter(new ImageAdapter(getActivity(),catsList,gridview));
        // GridView myGrid = (GridView) rootView.findViewById(R.id.gridView);
        mGridViewListener = (onItemClickListener) getContext();
        // mGridViewListener = (onItemClickListener)getActivity();
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(getActivity(),
                        "------->>>>>> Item Clicked: " + position, Toast.LENGTH_SHORT).show();
                //mGridViewListener.onCardClick(view, position);
                mGridViewListener.onItemClick(view,position);

            }
        });


        Point screenSize = new Point();
        getActivity().getWindowManager().getDefaultDisplay().getSize(screenSize);

        return rootView;
    }
///////////////////////INTERFACE FOR GRIDVIEW CLICK

   /* public interface onCardClickListener{
        void onCardClick(View view, int position);

    }*/

    public interface onItemClickListener{
        void onItemClick(View view, int position);

    }

    //////////////////////////////
    private final class MyLongClickListener implements View.OnLongClickListener {
        @Override
        public boolean onLongClick(View view){
            ClipData data = ClipData.newPlainText("", "");
            View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
            //MyDragShadowBuilder shadowBuilder = new MyDragShadowBuilder(view);
            view.startDrag(data, shadowBuilder, view, 0);
            return true;
        }
    }


    private final class MyTouchListener implements View.OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);
                //view.setVisibility(View.INVISIBLE);
                Log.v("onTouch", "ACTION_DOWN");
                return true;
            } else {
                return false;
            }
        }
    }
}