package com.example.raghavendra.raghavendr_hw9;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 *
 * to handle interaction events.
 * Use the {@link EventPage_Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EventPage_Fragment extends Fragment {

    private static Bitmap icon;
    private static final String ARG_SECTION_NUMBER = "section_number";

    static int position;
    static HashMap movieData;
    static String free;
    createEventListener cListener;
    directionsListener  dListener;
    static HashMap<String,?> movie;
    public EventPage_Fragment() {
        // Required empty public constructor
    }
    public static EventPage_Fragment newInstance(int position,HashMap<String, ?> mDataSet,Bitmap ic) {
        EventPage_Fragment fragment = new EventPage_Fragment();

        position = position;

        icon=ic;

        movieData = new HashMap();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    public static EventPage_Fragment newInstance(int position,List<Map<String, ?>> mDataSet,Bitmap ic) {
        EventPage_Fragment fragment = new EventPage_Fragment();

        position = position;

        icon=ic;

        movieData = new HashMap();
        movieData = (HashMap)mDataSet.get(position);
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ////System.out.println("----------->>>>>>>>>>>>>>>>>>> inflating event page on click");
        View  rootView =inflater.inflate(R.layout.event_details, container, false);
        //getMoviesList();
        TextView title = (TextView)rootView.findViewById(R.id.event_title);

        TextView desc = (TextView)rootView.findViewById(R.id.event_description);
        TextView start = (TextView)rootView.findViewById(R.id.start_time);
        TextView end = (TextView)rootView.findViewById(R.id.end_time);
        ImageView Img =  (ImageView)rootView.findViewById(R.id.movie_poster);
        ImageView cover =  (ImageView)rootView.findViewById(R.id.movie_cover);
         cover.setImageResource(R.drawable.default_img);
        if(icon==null)
            Img.setImageResource(R.drawable.default_img);
        else
        Img.setImageBitmap(icon);
        TextView venue = (TextView)rootView.findViewById(R.id.venue);

        title.setText((String) movieData.get("name"));
        desc.setText((String) movieData.get("description"));
         venue.setText((String) movieData.get("city"));
       start.setText((String) movieData.get("start_time"));
        String stopTime = (String) movieData.get("start_time");
        if(stopTime.length()!=0)
        end.setText(stopTime);

       final LatLng Elocation = new LatLng((Double)movieData.get("latitude"),(Double)movieData.get("longitude"));
     //   //System.out.println("----------->>>>>>>>>>>>>>>>>>> free event page on click " + free);


        Button direc = (Button) rootView.findViewById(R.id.directions);
       final Button going = (Button) rootView.findViewById(R.id.whoIsgoing);
        Button interested = (Button) rootView.findViewById(R.id.interested);

                going.setVisibility(View.GONE);

        cListener = (createEventListener) getContext();
        dListener = (directionsListener)getContext();

        direc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dListener.getDirections(Elocation);
            }
        });
        return  rootView;
    }

    public interface createEventListener{
        public         void createEvent();
    }

    public interface directionsListener{
        public         void getDirections(LatLng location);
    }
}
