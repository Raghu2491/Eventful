package com.example.raghavendra.raghavendr_hw9;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Raghavendra on 3/29/2016.
 */

public class App_CoverPage_Fragment extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";

        /*MovieData movieData = new MovieData();*/

    public App_CoverPage_Fragment() {
        // Required empty public constructor

    }

    public static App_CoverPage_Fragment newInstance(int sectionNumber) {
        App_CoverPage_Fragment fragment = new App_CoverPage_Fragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);

        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView;
        rootView = inflater.inflate(R.layout.fragment_aboutme, container, false);

        return rootView;
    }

}

