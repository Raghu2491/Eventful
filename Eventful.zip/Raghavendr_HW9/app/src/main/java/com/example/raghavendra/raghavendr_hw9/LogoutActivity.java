package com.example.raghavendra.raghavendr_hw9;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.firebase.client.Firebase;
import com.firebase.ui.auth.core.FirebaseLoginBaseActivity;
import com.firebase.ui.auth.core.FirebaseLoginError;

/**
 * Created by Apuroopa on 4/15/2016.
 */
public class LogoutActivity extends FirebaseLoginBaseActivity {
    private static final String FIREBASE_ERROR = "Firebase Error";
    EditText userNameET;
    EditText passwordET;
    private static final String USER_ERROR = "User Error";
    Firebase firebaseRef;
    private static final String FIREBASEREF = "https://example007.firebaseio.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getApplicationContext());

        firebaseRef = new Firebase(FIREBASEREF);
        super.onCreate(savedInstanceState);

        this.getFirebaseRef().unauth();


    }
    @Override
    protected void onFirebaseLoginProviderError(FirebaseLoginError firebaseLoginError) {
        Snackbar snackbar = Snackbar.
                make(userNameET, FIREBASE_ERROR + firebaseLoginError.message, Snackbar.LENGTH_SHORT);
        snackbar.show();
        resetFirebaseLoginPrompt();
    }
    @Override
    protected void onFirebaseLoginUserError(FirebaseLoginError firebaseLoginError) {
        Snackbar snackbar = Snackbar
                .make(userNameET, USER_ERROR + firebaseLoginError.message, Snackbar.LENGTH_SHORT);
        snackbar.show();
        resetFirebaseLoginPrompt();
    }

    @Override
    public Firebase getFirebaseRef() {
        return firebaseRef;
    }

    @Override
    public void onFirebaseLoggedOut() {


    }
}
